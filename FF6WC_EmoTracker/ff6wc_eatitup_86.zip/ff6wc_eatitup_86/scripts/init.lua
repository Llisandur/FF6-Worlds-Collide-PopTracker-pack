Tracker:AddItems("items/items.json")

if not (string.find(Tracker.ActiveVariantUID, "items_only")) then
Tracker:AddLayouts("layouts/gatedTracker.json")
else
Tracker:AddLayouts("layouts/tracker.json")
end

Tracker:AddLayouts("layouts/broadcast.json")