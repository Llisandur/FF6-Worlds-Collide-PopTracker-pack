Tracker:AddItems("items/items.json")

-- create custom items for the character/dragon portraits.
-- These allow the activated portraits to increment the progressive counters.
ScriptHost:LoadScript("scripts/custom/class.lua")
ScriptHost:LoadScript("scripts/custom/custom_item.lua")
ScriptHost:LoadScript("scripts/custom/character.lua")
ScriptHost:LoadScript("scripts/custom/dragon.lua")

-- Character portrait items
CharacterItem("Celes", "Celes", "images/PrtCeles.png")
CharacterItem("Cyan", "Cyan", "images/PrtCyan.png")
CharacterItem("Edgar", "Edgar", "images/PrtEdgar.png")
CharacterItem("Gau", "Gau", "images/PrtGau.png")
CharacterItem("Gogo", "Gogo", "images/PrtGogo.png")
CharacterItem("Locke", "Locke", "images/PrtLocke.png")
CharacterItem("Mog", "Mog", "images/PrtMog.png")
CharacterItem("Relm", "Relm", "images/PrtRelm.png")
CharacterItem("Sabin", "Sabin", "images/PrtSabin.png")
CharacterItem("Setzer", "Setzer", "images/PrtSetzer.png")
CharacterItem("Shadow", "Shadow", "images/PrtShadow.png")
CharacterItem("Strago", "Strago", "images/PrtStrago.png")
CharacterItem("Terra", "Terra", "images/PrtTerra.png")
CharacterItem("Umaro", "Umaro", "images/PrtUmaro.png")

-- Dragon items
DragonItem("Storm Dragon", "StormDragon", "images/StormDragon.png")
DragonItem("Ice Dragon", "IceDragon", "images/IceDragon.png")
DragonItem("Red Dragon", "RedDragon", "images/RedDragon.png")
DragonItem("Blue Dragon", "BlueDragon", "images/BlueDragon.png")
DragonItem("White Dragon", "WhiteDragon", "images/WhiteDragon.png")
DragonItem("Dirt Dragon", "DirtDragon", "images/DirtDragon.png")
DragonItem("Gold Dragon", "GoldDragon", "images/GoldDragon.png")
DragonItem("Skull Dragon", "SkullDragon", "images/SkullDragon.png")


if (string.find(Tracker.ActiveVariantUID, "items_only")) then
  Tracker:AddLayouts("layouts/tracker.json")
elseif (string.find(Tracker.ActiveVariantUID, "map_tracker")) then
  ScriptHost:LoadScript("scripts/logic.lua")
  Tracker:AddMaps("map_tracker/maps/maps.json")
  Tracker:AddLayouts("map_tracker/layouts/tracker.json")
  Tracker:AddLocations("map_tracker/locations/locations.json")
else
  Tracker:AddLayouts("layouts/gatedTracker.json")
end

Tracker:AddLayouts("layouts/broadcast.json")

if _VERSION == "Lua 5.3" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
else    
    print("Auto-tracker is unsupported by your tracker version")
end