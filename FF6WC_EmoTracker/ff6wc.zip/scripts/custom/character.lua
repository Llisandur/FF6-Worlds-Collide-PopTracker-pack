CharacterItem = CustomItem:extend()

--
-- Custom character item used for the character portraits on the
-- tracker.  This allows us to update the progressive character
-- counter when a portrait is clicked on the tracker.
--
function CharacterItem:init(name, code, imagePath)
    self:createItem(name)
    self.code = code
    self:setProperty("active", false)
    self.activeImage = ImageReference:FromPackRelativePath(imagePath)
    self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
    self.ItemInstance.PotentialIcon = self.activeImage

    self.ItemInstance.Icon = self.disabledImage    
end

function CharacterItem:setActive(active)
    self:setProperty("active", active)
end

function CharacterItem:getActive()
    return self:getProperty("active")
end

function CharacterItem:updateIcon()
    if self:getActive() then
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
    
    -- A character portrait has been toggled
    -- Update the progressive character counter.
    --
    -- NOTE: Ideally this would go in the onLeftClick/onRightClick
    --       handlers, but the active attribute seems to lag behind
    --       and isn't set in time.  Putting it here ensures that
    --       the property has been set before we call update characters.
    self:updateCharacterProgressiveItem()
end

function CharacterItem:onLeftClick()
    self:setActive(true)
end

function CharacterItem:onRightClick()
    self:setActive(false)
end

function CharacterItem:canProvideCode(code)
    return code == self.code
end

function CharacterItem:providesCode(code)
    if code == self.code and self.getActive() then
        return 1
    end
    return 0
end

function CharacterItem:advanceToCode(code)
    if code == nil or code == self.code then
        self:setActive(true)
    end
end

function CharacterItem:save()
    local saveData = {}
    saveData["active"] = self.getActive()
    return saveData
end

function CharacterItem:Load(data)
    if data["active"] ~= nil then
        self:setActive(data["active"])
    end
    return true
end

function CharacterItem:propertyChanged(key, value)
    self:updateIcon()
end

-- Function to update the progressive character object when
-- a new portrait is checked/unchecked.
function CharacterItem:updateCharacterProgressiveItem()
    characters = {"Celes", "Cyan", "Edgar", "Gau", "Gogo", "Locke", "Mog", "Relm", "Sabin", "Setzer", "Shadow", "Strago", "Terra", "Umaro"}
    
    counter = 0
    for index, character in ipairs(characters) do
        obj = Tracker:FindObjectForCode(character)
        if obj ~= nil and obj:Get("active") then
          counter = counter + 1
        end
    end
    
    -- Character progressive item doesn't define an entry for 0,
    -- so subtract one to correct the indexing.
    counter = math.max(0,counter -1)
    
    charobj = Tracker:FindObjectForCode("Char")
    if charobj ~= nil then
        charobj.CurrentStage = counter
    end
    
end