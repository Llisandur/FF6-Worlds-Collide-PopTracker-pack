DragonItem = CustomItem:extend()

--
-- Custom character item used for the character portraits on the
-- tracker.  This allows us to update the progressive character
-- counter when a portrait is clicked on the tracker.
--
function DragonItem:init(name, code, imagePath)
    self:createItem(name)
    self.code = code
    self:setProperty("active", false)
    self.activeImage = ImageReference:FromPackRelativePath(imagePath)
    self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
    self.ItemInstance.PotentialIcon = self.activeImage

    self.ItemInstance.Icon = self.disabledImage    
end

function DragonItem:setActive(active)
    self:setProperty("active", active)
end

function DragonItem:getActive()
    return self:getProperty("active")
end

function DragonItem:updateIcon()
    if self:getActive() then
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
    
    -- A dragon portrait has been toggled
    -- Update the progressive dragon counter.
    --
    -- NOTE: Ideally this would go in the setActive function,
    --       but the active attribute seems to lag behind
    --       and isn't set in time.  Putting it here ensures that
    --       the property has been set before we call update characters.
    self:updateCharacterProgressiveItem()
end

function DragonItem:onLeftClick()
    self:setActive(true)
end

function DragonItem:onRightClick()
    self:setActive(false)
end

function DragonItem:canProvideCode(code)
    return code == self.code
end

function DragonItem:providesCode(code)
    if code == self.code and self.getActive() then
        return 1
    end
    return 0
end

function DragonItem:advanceToCode(code)
    if code == nil or code == self.code then
        self:setActive(true)
    end
end

function DragonItem:save()
    local saveData = {}
    saveData["active"] = self.getActive()
    return saveData
end

function DragonItem:Load(data)
    if data["active"] ~= nil then
        self:setActive(data["active"])
    end
    return true
end

function DragonItem:propertyChanged(key, value)
    self:updateIcon()
end

-- Function to update the progressive dragon object when
-- a new portrait is checked/unchecked.
function DragonItem:updateCharacterProgressiveItem()
    dragons = {"StormDragon", "IceDragon", "RedDragon", "BlueDragon", "WhiteDragon", "DirtDragon", "GoldDragon", "SkullDragon"}
    
    counter = 0
    for index, dragon in ipairs(dragons) do
        obj = Tracker:FindObjectForCode(dragon)
        if obj ~= nil and obj:Get("active") then
          counter = counter + 1
        end
    end
    
    dragonobj = Tracker:FindObjectForCode("Dragon")
    if dragonobj ~= nil then
        dragonobj.CurrentStage = counter
    end
    
end